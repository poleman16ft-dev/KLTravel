package com.kl.travel.data

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertTrue

class LoungeAccessTest {
    @Test fun accessMatching() {
        val mine = setOf(LoungeProgram.PRIORITY_PASS, LoungeProgram.AIRLINE_STATUS)
        assertEquals(listOf(LoungeProgram.PRIORITY_PASS), LoungeProgram.matches("Plaza Premium Lounge (T1)", mine))
        assertEquals(listOf(LoungeProgram.AIRLINE_STATUS), LoungeProgram.matches("EVA Air Infinity Lounge", mine))
        assertEquals(emptyList<LoungeProgram>(), LoungeProgram.matches("Centurion Lounge", mine))
        assertEquals(listOf(LoungeProgram.AMEX), LoungeProgram.matches("The Centurion Lounge", setOf(LoungeProgram.AMEX)))
        assertEquals(
            setOf(LoungeProgram.AMEX, LoungeProgram.CHASE),
            LoungeProgram.decode(LoungeProgram.encode(setOf(LoungeProgram.AMEX, LoungeProgram.CHASE))),
        )
    }

    @Test fun businessCabinDetection() {
        assertTrue(LoungeProgram.isBusinessCabin("Business")); assertTrue(LoungeProgram.isBusinessCabin("first class"))
        assertTrue(LoungeProgram.isBusinessCabin("Royal Laurel Class"))
        assertFalse(LoungeProgram.isBusinessCabin("Economy")); assertFalse(LoungeProgram.isBusinessCabin("Premium Economy"))
        assertFalse(LoungeProgram.isBusinessCabin(""))
    }
}
