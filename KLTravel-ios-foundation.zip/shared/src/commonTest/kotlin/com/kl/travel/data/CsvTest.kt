package com.kl.travel.data

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue

class CsvTest {
    @Test fun quotesAndNewlinesInsideCells() {
        val rows = Csv.parse("a,b\r\n\"x, y\",\"he said \"\"hi\"\"\nline2\"\r\n")
        assertEquals(listOf("x, y", "he said \"hi\"\nline2"), rows[1])
    }

    @Test fun plainRowsWithAndWithoutTrailingNewline() {
        assertEquals(listOf(listOf("a", "b"), listOf("1", "2")), Csv.parse("a,b\n1,2"))
        assertEquals(listOf(listOf("a", "b"), listOf("1", "2")), Csv.parse("a,b\r\n1,2\r\n"))
    }

    @Test fun byteOrderMarkIsIgnored() {
        assertEquals("a", Csv.parse("\uFEFFa,b\n1,2")[0][0])
    }

    @Test fun emptyInputGivesNoRows() {
        assertTrue(Csv.parse("").isEmpty())
    }
}
