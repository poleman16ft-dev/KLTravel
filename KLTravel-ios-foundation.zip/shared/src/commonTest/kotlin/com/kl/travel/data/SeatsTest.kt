package com.kl.travel.data

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue

class SeatsTest {
    @Test fun seatsListEveryTravelerWithName() {
        val two = Seats.parse("Luis 3C / Sabrina 3D")
        assertEquals(listOf(SeatEntry("Luis", "3C"), SeatEntry("Sabrina", "3D")), two)
        assertEquals(listOf("3C", "3D"), Seats.parse("3C, 3D").map { it.seat })
        assertEquals(SeatEntry("Sabrina", "12B"), Seats.parse("Luis: 12a; Sabrina - 12B")[1])
        assertEquals(SeatEntry("Sabrina", "5F"), Seats.parse("5F Sabrina").single())
        assertEquals(listOf(SeatEntry("", "6K")), Seats.parse("6K"))
        assertEquals(3, Seats.parse("Luis 1A and Sabrina 1B & Kid 1C").size)
        assertTrue(Seats.parse("").isEmpty())
        assertEquals("Luis 3C, Sabrina 3D", Seats.summary("Luis 3C / Sabrina 3D"))
    }
}
