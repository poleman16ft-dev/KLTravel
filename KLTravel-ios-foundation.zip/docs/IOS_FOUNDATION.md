# iOS foundation: status and next steps

Companion to the "iOS Companion: Starter Brief" (the plan: Kotlin Multiplatform for logic, Compose Multiplatform for UI).
This file records what exists, how it is checked, and what comes next. Nothing here has been compiled yet:
the tooling used to write it had no Gradle, Android SDK or Mac. CI (below) is the first real check.

## What exists now
- `:shared` module (added in 1.25.3) with Android + iOS targets. Holds `Csv.kt`, `LoungeAccess.kt`, `Seats.kt`.
- `shared/src/commonTest`: `CsvTest`, `SeatsTest`, `LoungeAccessTest`, built from assertions that already pass in `:app`.
  They run on the JVM and on the iOS Simulator, so shared logic is proven on both platforms.
- `.github/workflows/ci.yml`: an `android` job (Linux) and an `ios-shared` job (macOS). The macOS job is how iOS
  breakage gets caught without a local Mac. First run may need small fixes (SDK paths, task names).

## Where each file stands
Scan was by imports plus a look at the files, so treat it as a starting point: a file can also use `java.*` inline
(`Airlines.kt` calls `java.net.URLEncoder` without importing it).

| Group | Files | What moving to `commonMain` needs |
|---|---|---|
| Nearly there (`java.time` / small `java.*`) | `GoogleUsage`, `Layovers`, `ReceiptParser`, `SheetParser`, `Airlines` (URL encoding) | `java.time` -> `kotlinx-datetime`; write a small URL encoder or use an `expect/actual` |
| Plain data + parsing that need a JSON library (`org.json`) | `Trips`, `Backup`, `TransportImages`, `CurrencyClient` | `org.json` -> `kotlinx-serialization-json` |
| Network clients | `FlightClient`, `WeatherClient`, `LoungeClient`, `RoutesClient`, `HotelPhotoClient`, `TransportPhotoClient` | Ktor client + serialization; `Context`/cache-file parts stay per-platform |
| Android-bound | `Db`, `Models` (Room annotations), `Prefs`, `DocStore`, `SheetRepository`, `MapsKey`, `Origin`, `receipt/ReceiptTools`, `work/*`, `widget/*` | Room upgrade to a multiplatform version (2.7+), a settings store, and `expect/actual` bridges |

UI (about 3,100 lines): `Theme`, `TimelineScreen`, `CategoryScreen`, `ToolsScreen` have no Android-specific references
and are the natural first screens for Compose Multiplatform. `VaultScreen`, `DetailScreen`, `SettingsScreen`,
`LoungeCard`, `TransportPhoto`, `ExpensesScreen`, `Util`, `SetupWizard` need the most bridging.

## Suggested order
1. Add `kotlinx-datetime`, `kotlinx-serialization-json` and Ktor to `:shared`.
2. Move `Models` (data classes only, Room annotations split off), `SheetParser`, `Layovers`, `GoogleUsage`, `ReceiptParser`. Move their tests to `commonTest`. Keep `:app` tests green after every step.
3. Upgrade Room to a multiplatform version and move the database.
4. Add the Compose Multiplatform plugin. Move `Theme` and the Timeline screen first.
5. Create the iOS app shell (needs a Mac): add `binaries.framework` to the iOS targets in `shared/build.gradle.kts` and an Xcode project that hosts the shared UI.
6. Platform bridges: receipt text recognition (Apple Vision), background alerts (BGTaskScheduler), maps (WebView route map first), WidgetKit widget (Swift), Keychain-backed vault.

## Known iOS limits (platform, not bugs)
- Background alerts will be less reliable than on Android (iOS controls when background work runs).
- No equivalent of Android's screenshot blocking for the document vault.
- Widgets must be written in SwiftUI/WidgetKit regardless of the shared code.
- No sideloading: iPhone testing goes through Xcode or TestFlight, and App Store distribution needs the paid Apple Developer account.

## Versioning
This change adds tests, CI and docs only. No app code or version changed, so `CHANGELOG.md` and `appVersion` were left
alone (a unit test ties them together). Log it under the next version bump.
